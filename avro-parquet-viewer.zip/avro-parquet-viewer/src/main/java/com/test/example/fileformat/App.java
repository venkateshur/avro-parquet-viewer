package com.test.example.fileformat;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.test.example.fileformat.model.AvroFileReader;
import com.test.example.fileformat.model.ParquetFileReader;
import com.test.example.fileformat.util.Common;
import com.test.example.fileformat.util.S3Utils;
import org.apache.commons.io.FileUtils;

import java.util.List;
import java.util.Objects;
import java.util.Properties;

public class App {
    public static void main(String[] args) throws Exception {
        String propsPath = args[0];
        String fileType = args[1];
        Properties props = Common.loadProperties(propsPath);

        AmazonS3 s3Client = S3Utils.buildS3Client(props.getProperty("AWS_ACCESS_KEY"), props.getProperty("AWS_SECRET_KEY"),
                props.getProperty("REGION"));

        if (Objects.equals(fileType, "AVRO")) {
            downloadFileToLocal(s3Client, props.getProperty("S3_AVRO_PATH"), props.getProperty("LOCAL_AVRO_PATH"));
            AvroFileReader avroFileReader = new AvroFileReader(FileUtils.getFile(props.getProperty("LOCAL_AVRO_PATH")));
            Common.writeSchema(avroFileReader.getSchema(), props.getProperty("LOCAL_AVRO_SCHEMA_PATH"));
            S3Utils.uploadLocalFileTos3(s3Client, props.getProperty("LOCAL_AVRO_SCHEMA_PATH"), props.getProperty("S3_AVRO_SCHEMA_PATH"));
            System.out.println(avroFileReader.getNumRecords());
            avroFileReader.getRecords(avroFileReader.getNumRecords()).forEach(System.out::println);
            Common.deleteFile(props.getProperty("LOCAL_AVRO_SCHEMA_PATH"));

        } else if (Objects.equals(fileType, "PARQUET")) {

            downloadFileToLocal(s3Client, props.getProperty("S3_AVRO_PATH"), props.getProperty("LOCAL_PARQUET_PATH"));
            ParquetFileReader parquetFileReader = new ParquetFileReader(FileUtils.getFile(props.getProperty("LOCAL_PARQUET_PATH")));
            Common.writeSchema(parquetFileReader.getSchema(), props.getProperty("LOCAL_PARQUET_SCHEMA_PATH"));
            S3Utils.uploadLocalFileTos3(s3Client, props.getProperty("LOCAL_PARQUET_SCHEMA_PATH"), props.getProperty("S3_PARQUET_SCHEMA_PATH"));
            System.out.println(parquetFileReader.getNumRecords());
            parquetFileReader.getRecords(parquetFileReader.getNumRecords()).forEach(System.out::println);
            Common.deleteFile(props.getProperty("LOCAL_PARQUET_SCHEMA_PATH"));
        } else {
            System.out.println("invalid file format: " + fileType);
            throw new RuntimeException("invalid file format: " + fileType);
        }
    }

    private static void downloadFileToLocal(AmazonS3 s3Client, String s3path, String localPath) throws Exception {
        List<S3Object> s3ObjectList = S3Utils.listFilesFromS3(s3Client, s3path);
        if (!s3ObjectList.isEmpty()) {
            S3Utils.downloadS3File(s3Client, s3ObjectList.get(0).toString(), localPath);
        }
    }
}
