package com.test.example.fileformat;

import org.apache.commons.io.FileUtils;
import java.io.IOException;
import java.util.Objects;

public class App {
    public static void main(String [] args) throws IOException {
        String filePath = args[0];
        String fileType = args[1];

        if (Objects.equals(filePath, "AVRO")){
            AvroFileReader avroFileReader = new AvroFileReader(FileUtils.getFile(filePath));
            System.out.println(avroFileReader.getSchema());
            System.out.println(avroFileReader.getNumRecords());
            avroFileReader.getRecords(avroFileReader.getNumRecords()).stream().forEach(System.out::println);
        } else if (Objects.equals(filePath, "PARQUET")){
            ParquetFileReader parquetFileReader = new ParquetFileReader(FileUtils.getFile(filePath));
            System.out.println(parquetFileReader.getSchema());
            System.out.println(parquetFileReader.getNumRecords());
            parquetFileReader.getRecords(parquetFileReader.getNumRecords()).stream().forEach(System.out::println);
        } else {
            System.out.println("invalid file format: " + fileType);
            throw new RuntimeException("invalid file format: " + fileType);
        }
    }
}
