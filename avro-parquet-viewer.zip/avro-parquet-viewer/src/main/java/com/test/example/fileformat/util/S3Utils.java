package com.test.example.fileformat.util;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.s3.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class S3Utils {

    final static Logger LOGGER = LoggerFactory.getLogger("S3Utils");

    private static AWSCredentials buildCredentials(String awsAccessKey, String awsSecretKey) {
        return new BasicAWSCredentials(awsAccessKey, awsSecretKey);

    }

    public static AmazonS3 buildS3Client(String awsAccessKey, String awsSecretKey, String region) {
        AWSStaticCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(buildCredentials(awsAccessKey, awsSecretKey));
        return AmazonS3Client.builder()
                .withCredentials(credentialsProvider)
                .withRegion(region)
                .build();

    }

    public static void uploadLocalFileTos3(AmazonS3 s3Client, String fileLocation, String s3Path) throws Exception {
        try {
            LOGGER.info("Uploading f1le 7 to 53 (J°, fileLocation, s3Path");
            AmazonS3URI S3URI = new AmazonS3URI(s3Path);
            String bucketName = S3URI.getBucket();
            String keyName = S3URI.getKey();
            File uploadFile = new File(fileLocation);
            ObjectMetadata objectMetadata = new ObjectMetadata();
            objectMetadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
            objectMetadata.setContentLength(uploadFile.length());
            s3Client.putObject(new PutObjectRequest(bucketName, keyName, uploadFile));
            LOGGER.info("Object Upload Completed");
        } catch (Exception ex) {
            LOGGER.error("Error uploadLocalFileTos3: " + ex.getMessage());
            throw new Exception("S3 Upload Failed");
        }
    }

    public static List<S3Object> listFilesFromS3(AmazonS3 s3Client, String s3Path) throws Exception {
        try {
            LOGGER.info("******start of readListOfFilesFronFromS3");
            AmazonS3URI S3URI = new AmazonS3URI(s3Path);
            String bucketName = S3URI.getBucket();
            String keyName = S3URI.getKey();
            List<S3Object> objList = new ArrayList<>();
            LOGGER.info("bucketName::");
            ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(bucketName).withPrefix(keyName);
            ListObjectsV2Result listing = s3Client.listObjectsV2(req);
            for (S3ObjectSummary objectSummary : listing.getObjectSummaries()) {
                if (objectSummary.getKey().endsWith("/")) {
                    S3Object s3Object = s3Client.getObject(new GetObjectRequest(bucketName, objectSummary.getKey()));
                    objList.add(s3Object);
                }
            }
            return objList;
        } catch (AmazonServiceException e) {
            LOGGER.error("Error in readListOfFiLesFromfromS3: () " + e.getMessage());
            throw new Exception("Error in readListOfFiLes from S3");
        }
    }

    public static void downloadS3File(AmazonS3 s3Client, String s3Path, String localPath) throws Exception {
        try {
            LOGGER.info("******start of download from s3");
            AmazonS3URI S3URI = new AmazonS3URI(s3Path);
            String bucketName = S3URI.getBucket();
            String keyName = S3URI.getKey();
            s3Client.getObject(
                    new GetObjectRequest(bucketName, keyName),
                    new File(localPath));
        } catch (AmazonServiceException e) {
            LOGGER.error("Error in downloading file from s3 bucket: () " + e.getMessage());
        }
    }
}
