package com.test.example.fileformat.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class Common {
    public static Properties loadProperties(String propsPath) throws IOException {
        Properties properties = new Properties();
        properties.load(new FileInputStream(propsPath));
        return properties;
    }

    public static void writeSchema(String schema, String path) throws IOException {
        File file = new File(path);
        FileWriter wr = new FileWriter(file);
        wr.write(schema);
        wr.flush();
        wr.close();
    }

    public static boolean deleteFile(String path) throws IOException {
        File file = new File(path);
        return file.delete();
    }
}
